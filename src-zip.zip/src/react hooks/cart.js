import { useState } from "react";

const MyCart =()=>{

    return(
        <section className="container">
            <div className="row mt-4">
                <h3 className="text-center"> 1: Items in Cart </h3>
            </div>
            <table className="table text-center">
                <thead>
                    <tr>
                        <th><strong> Item Name </strong> </th>
                        <th> Photo </th>
                        <th> Price </th>
                        <th> Quantity </th>
                        <th> Total </th>
                        <th> Action </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td> Apple</td>
                        <td> Image</td>
                        <td> 200 </td>
                        <td> 1 </td>
                        <td> 200 </td>
                        <td> 
                            <button className="btn btn-danger btn-sm"> 
                                <i className="fa fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
            
        </section>
    )
}

export default MyCart;